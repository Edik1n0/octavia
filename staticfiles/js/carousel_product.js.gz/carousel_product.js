$(document).ready(function () {
    $('#product-slider').owlCarousel({
        loop: true,
        smartSpeed: 2000,
        items: 1,
        margin: 20,
        nav: true
    })
})
  